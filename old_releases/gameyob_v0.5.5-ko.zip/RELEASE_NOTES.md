# GameYob v0.5.5-ko release record

This is an unofficial MIT-licensed GameYob homebrew release. It contains emulator binaries, source-linked documentation, language examples, and required license notices. It does not contain a commercial ROM or BIOS.

## Development framework

The Nintendo DS and DSi targets now build with BlocksDS 1.22.2 and the Wonderful toolchain. CI pins the `skylyrac/blocksds:slim-v1.22.2` image by digest and produces the established `gameyob.nds` and `gameyob_dsi.nds` filenames. Legacy libfat internals, removed console formatting calls, ARM7 initialization, DSi camera services, and ELF-to-NDS packaging were updated for the current SDK.

BlocksDS targets Nintendo DS-family software. The native `gameyob.3dsx` target therefore remains a separate libctru/devkitARM build.

The native 3DS target now builds with the current devkitPro ARM ABI, uses the public libctru framebuffer and UTF-8 SD APIs, resolves selected ROMs to stable absolute paths, and uses the original hardware CSND service first. NDSP remains the fallback when CSND is unavailable. The Debug tab reports the selected backend, queue result, and generated non-zero sample count. No DSP firmware is included or distributed.

Native 3DS rendering composes a complete 160×144 frame away from the scanout buffers and presents it through the verified centered direct-framebuffer path. Native 3DS aspect/full-screen scaling is intentionally excluded from `v0.5.5-ko` because both tested prototypes produced unacceptable real-hardware output or performance. A hardware-verified implementation is tracked for `v0.5.6-ko`; DS/DSi scaling remains available. DS, DSi, and 3DS can select an exact 0x900-byte GBC BIOS file; saving settings records the absolute `biosfile` path in `gameyobds.ini`. No BIOS is included or distributed.

## Link changes

- Local link now closes active wireless state, initializes the secondary `.sa2` save once, checks allocation/load failures, and maps SRAM before emulator initialization.
- DS/DSi raw NiFi and native 3DS LAN protocol v3 retains bounded discovery, ACK/retry, CRC, sequence, fragment, input-buffer, retransmission, and state-hash checks while synchronizing initial SRAM plus MBC3/HuC3 clock data.
- Wireless peers now advertise a full-file ROM fingerprint. Cross-version link games load and verify the exact peer ROM instead of comparing only the visible title, so two hacks with the same title are not confused.
- No-network and no-peer paths return to the menu instead of freezing.

## RTC changes

MBC3 and HuC3 clocks now advance using elapsed host seconds without a timezone offset. MBC3 implements the 0→1 latch edge, a stable latched snapshot, halt behavior, 9-bit day rollover, and carry. Invalid or backward host timestamps reset the baseline safely. RTC-only MBC3 cartridges with no external SRAM can create and update their clock save, and save states refresh their time baseline without changing the existing serialized `ClockStruct` layout.

## Patched-ROM compatibility

- ROM banking follows physical file length instead of rounding every file to the next power of two.
- Non-power-of-two and out-of-range bank requests are mirrored within the physical bank count.
- Partial final banks and recycled cache slots are initialized to `0xFF`.
- Standard RAM header values through 128 KiB (`0x04`) and 64 KiB (`0x05`) are decoded correctly.
- The MBC5 rumble mapper check uses the cartridge type byte.
- Files beyond the 512-bank/8 MiB hardware boundary fail safely rather than indexing outside the bank map.

Custom mapper hardware such as MMM01/MBC4 and incomplete MBC7/HuC behavior remains outside this release's implemented compatibility boundary.

## Documentation and languages

English, Japanese, and Korean guides cover installation, controls, every menu group, saves, cheats, languages, display and borders, Game Boy modes, sound/debug switches, local/wireless link, RTC, patched ROMs, and troubleshooting:

- [English guide](../guides/user-guide.en.md)
- [日本語ガイド](../guides/user-guide.ja.md)
- [한국어 가이드](../guides/user-guide.ko.md)

English, Japanese, and Korean remain embedded. Editable INI, JSON, XML, and YAML examples are included. Saving settings creates a non-destructive English `gameyob_language.ini` template beside `gameyobds.ini`.

## Validation

- BlocksDS DS and DSi clean build: pass.
- Native 3DSX clean build: pass.
- Portable tests for protocol/CRC/UTF-8 identity, RTC rollover/halt/carry, physical ROM layouts/RAM headers, rendering rules, noise LFSR, SGB borders, localization formats, and Unicode text: pass.
- The release archive is generated deterministically and includes SHA-256 checksums and all redistributed license notices.
- Physical DS/DSi operation and RTC behavior were accepted on hardware. Native 3DS ROM operation was also accepted with the fixed centered 160×144 display; occasional gameplay frame drops remain a documented limitation.
- Native 3DS scaling is not shipped in this release. Its replacement requires stable output and acceptable Old 3DS/2DS performance before the `v0.5.6-ko` target can be accepted.

Physical DS↔DS, DSi↔DSi, 3DS DS-mode↔DS/DSi raw-NiFi tests and native 3DS↔3DS LAN tests require two real systems and remain explicitly documented in the repository TODO. A native-3DS/`.nds` transport bridge is not implemented.

# GameYob v0.5.5-ko 릴리스 기록

이 배포판은 MIT 라이선스의 비공식 GameYob 홈브루 릴리스입니다. 에뮬레이터 실행 파일, 소스와 연결된 문서, 언어 예제 및 필수 라이선스 고지를 포함하며 상용 ROM이나 BIOS는 포함하지 않습니다.

## 개발 환경

Nintendo DS/DSi 대상을 BlocksDS 1.22.2와 Wonderful 툴체인으로 전환했습니다. CI는 `skylyrac/blocksds:slim-v1.22.2` 이미지를 다이제스트로 고정하고 기존 파일명 `gameyob.nds`, `gameyob_dsi.nds`를 만듭니다. 최신 SDK에 맞춰 구형 libfat 내부 접근, 삭제된 콘솔 출력 함수, ARM7 초기화, DSi 카메라 서비스 및 ELF→NDS 패키징을 수정했습니다.

BlocksDS는 Nintendo DS 계열 개발 환경이므로 네이티브 `gameyob.3dsx`는 별도 libctru/devkitARM 빌드를 유지합니다. 3DSX는 실기에서 DSP 펌웨어 파일에 의존하지 않도록 원래 하드웨어 CSND 서비스를 우선 사용하고, 사용할 수 없을 때 NDSP로 대체합니다. 디버그 탭의 사운드 상태 화면에서 백엔드·큐 결과·0이 아닌 생성 샘플 수를 확인할 수 있습니다.

네이티브 3DS 렌더러는 160×144 완성 프레임을 화면 출력 버퍼 밖에서 구성한 뒤 검증된 중앙 직접 프레임버퍼 경로로 표시합니다. 시험한 두 확대 방식 모두 실기 화면 출력이나 성능이 배포 기준을 충족하지 못해 `v0.5.5-ko`에서는 네이티브 3DS의 비율·전체 화면 확대를 의도적으로 제외했습니다. 실기 검증된 확대 구현은 `v0.5.6-ko` 목표로 남기며 DS/DSi 확대는 유지합니다. DS·DSi·3DS 모두 정확히 0x900바이트인 GBC BIOS 파일을 선택할 수 있으며, 설정 저장 시 절대 `biosfile` 경로를 `gameyobds.ini`에 기록합니다. BIOS는 배포물에 포함하지 않습니다.

## 링크 변경

- 로컬 링크는 활성 무선 상태를 닫고 두 번째 `.sa2` 세이브를 한 번만 초기화하며 할당·불러오기 실패를 검사하고 에뮬레이터 초기화 전에 SRAM을 매핑합니다.
- DS/DSi raw NiFi와 네이티브 3DS LAN 프로토콜 v3은 제한 시간 검색, ACK/재전송, CRC, 순번, 분할, 입력 버퍼, 누락 입력 재전송 및 상태 해시 검사를 유지하면서 초기 SRAM과 MBC3/HuC3 시계 정보를 함께 동기화합니다.
- 무선 상대는 전체 파일 ROM 지문을 교환합니다. 서로 다른 버전 게임은 화면 제목만 비교하지 않고 정확한 상대 ROM을 불러와 검증하므로, 제목이 같은 서로 다른 핵을 혼동하지 않습니다.
- 네트워크가 없거나 상대가 없을 때 멈추지 않고 메뉴로 돌아옵니다.

## RTC 변경

MBC3/HuC3 시계는 시간대 보정 없이 호스트의 실제 경과 초를 사용합니다. MBC3의 0→1 래치 경계, 고정 래치 스냅샷, 정지, 9비트 날짜 롤오버 및 캐리를 구현했습니다. 잘못되거나 과거로 돌아간 호스트 시각은 기준선을 안전하게 다시 잡습니다. 외부 SRAM이 없는 RTC 전용 MBC3도 시계 세이브를 만들고 갱신하며, 기존 직렬화 `ClockStruct` 배치를 바꾸지 않고 상태 파일의 기준 시각을 갱신합니다.

## 패치 ROM 호환성

- 모든 파일을 다음 2의 거듭제곱으로 반올림하지 않고 실제 파일 길이로 ROM 뱅크를 계산합니다.
- 비2제곱 및 범위를 벗어난 뱅크 요청은 실제 뱅크 수 안에서 미러링합니다.
- 불완전한 마지막 뱅크와 재사용 캐시 슬롯을 `0xFF`로 초기화합니다.
- 128KiB(`0x04`)와 64KiB(`0x05`)를 포함한 표준 RAM 헤더 값을 올바르게 처리합니다.
- MBC5 럼블 여부를 실제 카트리지 종류 값으로 판정합니다.
- 512뱅크/8MiB 하드웨어 경계를 넘는 파일은 뱅크 맵 경계를 침범하지 않고 안전하게 중단합니다.

MMM01/MBC4 같은 사용자 매퍼 및 아직 불완전한 MBC7/HuC 하드웨어 동작은 이 릴리스의 구현 범위 밖에 남아 있습니다.

## 문서와 언어

영어·일본어·한국어 가이드에 설치, 조작, 모든 메뉴 그룹, 세이브, 치트, 언어, 화면·보더, Game Boy 모드, 사운드·디버그, 로컬·무선 링크, RTC, 패치 ROM 및 문제 해결 방법을 기록했습니다.

영어·일본어·한국어는 실행 파일에 계속 내장되며 편집 가능한 INI·JSON·XML·YAML 예제를 함께 제공합니다. 설정 저장 시 `gameyobds.ini` 옆에 기존 파일을 덮어쓰지 않는 영어 `gameyob_language.ini` 템플릿을 생성합니다.

## 검증

- BlocksDS DS/DSi 클린 빌드: 통과.
- 네이티브 3DSX 클린 빌드: 통과.
- 프로토콜/CRC/UTF-8 식별자, RTC 롤오버·정지·캐리, 실제 ROM 배치/RAM 헤더, 렌더링 규칙, 노이즈 LFSR, SGB 보더, 언어 형식 및 유니코드 텍스트 자동 테스트: 통과.
- 릴리스 압축은 결정론적으로 만들고 SHA-256 및 모든 재배포 라이선스 고지를 포함합니다.
- DS/DSi 구동과 RTC 기능은 실기에서 승인되었고, 네이티브 3DS도 중앙 160×144 고정 화면으로 ROM 정상 구동을 승인했습니다. 다만 게임 중 간헐적인 프레임 드롭은 알려진 제한으로 남깁니다.
- 네이티브 3DS 확대는 이번 릴리스에 포함하지 않습니다. `v0.5.6-ko` 목표 구현은 Old 3DS/2DS에서 안정적인 화면과 충분한 성능을 확인한 뒤 승인합니다.

DS↔DS, DSi↔DSi, 3DS DS 모드↔DS/DSi raw NiFi 및 네이티브 3DS↔3DS LAN 실기 검증에는 실제 기기 두 대가 필요하므로 저장소 TODO에 명시합니다. 네이티브 3DS와 `.nds` 사이의 전송 브리지는 구현하지 않았습니다.
