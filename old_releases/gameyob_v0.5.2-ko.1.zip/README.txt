GameYob v0.5.2-ko.1

gameyob.nds
  DS/DS Lite, 3DS DS mode and most flashcards.

gameyob_dsi.nds
  Launchers that explicitly support DSi mode.

Enable automatic DLDI patching when required by your flashcard.
Detailed changes, build information and verification records:
https://github.com/GimoXagros/GameYob/blob/master/docs/releases/v0.5.2-ko.1.md

GameYob and this modification are distributed under the MIT License.
The embedded Korean bitmap font is derived from Galmuri and distributed
under the SIL Open Font License 1.1. See the included license files.
