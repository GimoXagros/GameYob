# GameYob v0.5.8-ko release record

## English

This DS/DSi-focused release adds software support for the MMM01 multicart
mapper and introduces a bounded, independent host-SNES execution foundation
for SGB commands. It contains redistributable homebrew only; no ROM, BIOS, DSP
firmware, or native 3DSX executable is included.

### Release changes

- Added independent MMM01 handling for types `0x0B`, `0x0C`, and `0x0D`.
  The implementation covers the last-32-KiB power-on menu, one-way mapping
  enable, ROM/RAM write masks, ROM base and switched banks, mode 0/1,
  multiplexing, RAM enable/banking, bank-zero aliasing, and physical-bank
  normalization.
- Connected MMM01 RAM to the existing SRAM, battery save, and autosave paths.
  Save-state version 7 records every MMM01 register and reconstructs the
  memory map while older state versions remain loadable.
- Treated legacy types `0x15`-`0x17` as explicit undocumented/unknown mappers
  instead of guessing their behavior or silently using MBC5. MBC7 and HuC
  hardware validation remains outside this release.
- Added `SgbHost`, `SgbHostCpu`, `SgbHostPpu`, and `SgbHostApu`. The runtime is
  allocated only in SGB mode and reset on ROM unload, reset, or mode changes.
- Connected `DATA_SND` and `DATA_TRN` to bounded SNES WRAM/PPU/APU address
  writes, and connected `JUMP` to host PC/PBR and NMI state. Unsupported host
  CPU opcodes stop with an explicit fault rather than acting as silent no-ops.
- Connected `SOU_TRN` and `SOUND` to an independent APU RAM/program path. The
  current SPC700 subset and BRR voice decoder produce a separate PCM source,
  which the DS audio hardware mixes beside the unchanged four GB channels with
  clipping bounds.
- Connected `CHR_TRN` to host VRAM and decoded the documented prototype
  `OBJ_TRN` OAM/tile/palette fields in the host PPU. Retail SGB revisions are
  documented to ignore `OBJ_TRN`; complete prototype OBJ composition into the
  DS output remains TODO.
- Explicitly serialized the new host state in save-state version 7, without
  relying on compiler structure padding.
- Added portable mapper and host-runtime regression tests and retained the
  pinned BlocksDS 1.22.2 build.

### Incomplete host-SNES scope

The new SGB host layer is a functional foundation, not a complete SNES
emulator. Full 65C816/SPC700 opcode and cycle coverage, complete DSP
envelopes/echo, and final prototype OBJ composition are still required.
Accordingly, README TODO #5 remains open and states the exact remainder.

### Package contents

- `gameyob.nds`
- `gameyob_dsi.nds`
- English, Japanese, and Korean user guides
- Editable INI, JSON, XML, and YAML language examples
- License notices and per-file SHA-256 checksums

## 한국어

이 DS/DSi 중심 릴리스는 MMM01 멀티카트 매퍼의 소프트웨어 지원과 SGB 명령을
위한 독립적이고 경계가 있는 호스트 SNES 실행 기반을 추가합니다. 재배포 가능한
홈브루만 포함하며 게임 ROM, BIOS, DSP 펌웨어 및 네이티브 3DSX는 포함하지
않습니다.

### 릴리스 변경 사항

- `0x0B`·`0x0C`·`0x0D`를 독립 MMM01로 처리합니다. 마지막 32KiB 메뉴의
  전원 투입 매핑, 단방향 매핑 활성화, ROM/RAM 쓰기 마스크, ROM 기준·전환
  뱅크, 모드 0/1, 멀티플렉스, RAM 활성화·뱅킹, 뱅크 0 대체 및 실제 ROM
  뱅크 경계 정규화를 구현했습니다.
- MMM01 RAM을 기존 SRAM·배터리 저장·자동 저장 경로에 연결했습니다. 상태
  파일 버전 7은 모든 MMM01 레지스터를 기록하고 로드 뒤 메모리 매핑을 다시
  구성하며, 이전 버전 상태 파일도 계속 불러옵니다.
- 기존 형식 `0x15`-`0x17`은 MBC5로 조용히 대체하지 않고 사양 미상 매퍼로
  명시합니다. MBC7과 HuC의 실기 검증은 이번 릴리스 범위가 아닙니다.
- `SgbHost`, `SgbHostCpu`, `SgbHostPpu`, `SgbHostApu` 계층을 추가했습니다.
  SGB 모드에서만 할당하며 ROM 종료·재설정·모드 변경 때 초기화합니다.
- `DATA_SND`·`DATA_TRN`을 경계 검사된 SNES WRAM/PPU/APU 쓰기에 연결하고,
  `JUMP`를 호스트 PC/PBR·NMI 상태에 연결했습니다. 지원하지 않는 호스트 CPU
  명령은 조용히 무시하지 않고 명시적인 오류 상태에서 중단합니다.
- `SOU_TRN`·`SOUND`를 독립 APU RAM·프로그램 경로에 연결했습니다. 현재의
  SPC700 부분 집합과 BRR 보이스 디코더가 별도 PCM 소스를 만들며, DS 사운드
  하드웨어가 기존 GB 4채널을 변경하지 않고 함께 출력합니다.
- `CHR_TRN`을 호스트 VRAM에 연결하고 문서화된 프로토타입 `OBJ_TRN`의
  OAM·타일·팔레트 필드를 호스트 PPU에서 디코딩합니다. 일반 판매 SGB는
  `OBJ_TRN`을 무시하며, 프로토타입 OBJ의 최종 DS 화면 합성은 TODO로 남습니다.
- 새 호스트 상태를 컴파일러 구조체 패딩에 의존하지 않고 상태 파일 버전 7에
  명시적으로 기록합니다.
- MMM01·SGB 호스트 자동 회귀시험을 추가하고 고정된 BlocksDS 1.22.2 빌드를
  유지합니다.

### 아직 완전하지 않은 호스트 SNES 범위

새 SGB 호스트 계층은 실제 동작 기반이지만 완전한 SNES 에뮬레이터는 아닙니다.
65C816/SPC700의 전체 명령·사이클, DSP 엔벌로프·에코 및 프로토타입 OBJ의 최종
화면 합성이 남아 있습니다. 따라서 README TODO #5는 완료 처리하지 않고 남은
범위를 정확히 기록합니다.

### 압축 파일 구성

- `gameyob.nds`
- `gameyob_dsi.nds`
- 영어·일본어·한국어 사용자 가이드
- 수정 가능한 INI·JSON·XML·YAML 언어 예제
- 라이선스 고지와 파일별 SHA-256 체크섬
