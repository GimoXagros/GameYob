# GameYob v0.5.10 release record

## English

This DS/DSi-focused release advances state-file safety, the experimental SGB
host CPU, and portable DS NiFi packet handling. It is built with the pinned
BlocksDS 1.22.2 environment. The archive contains redistributable homebrew
only: no game ROM, BIOS, DSP firmware, or native 3DSX executable is included.
Nintendo 3DS users can run `gameyob.nds` in DS mode.

### Changes

- Kept save-state format 8 and added exact version 1-8 prefix sizing, checked
  mapper/SGB tail lengths, deterministic truncation/mutation tests, and full
  tail preflight before large emulator memory regions are modified.
- Expanded experimental 65C816 opcode dispatch from 51/256 to 256/256 with
  tested indirect and stack-relative addressing, memory arithmetic and shifts,
  control flow, BRK/COP, mode-sensitive NMI entry, MVN/MVP, and data-bank and
  direct-page boundary behavior.
- Hardened DS NiFi fragmentation against malformed sizes, missing/reordered
  fragments, duplicate replacement, sequence wrap, and invalid ACK behavior.
- Added checked SGB opcode inventory plus normal, UBSan, AddressSanitizer and
  leak-test coverage to the repository preflight.
- Updated the English, Japanese, and Korean guides and in-program version data.

### Important limitations

- 256/256 is opcode-dispatch coverage, not a complete or cycle-accurate SNES
  CPU claim. Cycle accounting and penalties, externally driven IRQ/reference
  traces, and real SGB host-program validation remain.
- SPC700 remains at 21/256. DSP envelopes/echo and final prototype host OBJ
  composition remain incomplete.
- State loading is structurally preflighted but not fully transactional; keep
  backups, especially for legacy state files.
- Portable radio tests do not replace physical DS-to-DS, DSi-to-DSi, or 3DS
  DS-mode wireless validation.
- Native 3DSX work remains paused in `backup/3dsx` and is not included.

### Package contents

- `gameyob.nds`
- `gameyob_dsi.nds`
- English, Japanese, and Korean user guides
- Editable INI, JSON, XML, and YAML language examples
- License notices and per-file SHA-256 checksums

## 한국어

이 DS/DSi 중심 릴리스는 상태 파일 안전성, 실험적 SGB 호스트 CPU 및 DS NiFi
패킷 처리를 보강합니다. 고정된 BlocksDS 1.22.2 환경으로 빌드하며 재배포 가능한
홈브루만 포함합니다. 게임 ROM, BIOS, DSP 펌웨어 및 네이티브 3DSX 실행 파일은
포함하지 않습니다. Nintendo 3DS에서는 `gameyob.nds`를 DS 모드로 실행할 수
있습니다.

### 변경 사항

- 상태 형식 8을 유지하며 버전 1~8의 정확한 공통 길이, 매퍼/SGB tail 길이 검사,
  절단·변조 시험 및 대형 메모리 적용 전 전체 tail 구조 검사를 추가했습니다.
- 실험적 65C816 opcode 분기 범위를 51/256에서 256/256으로 확대하고 간접·스택
  상대 주소, 메모리 연산·시프트, 제어 흐름, BRK/COP, 모드별 NMI 진입,
  MVN/MVP 및 데이터 뱅크·Direct Page 경계를 시험했습니다.
- 잘못된 크기, 누락·순서 변경 조각, 중복 덮어쓰기, 순번 wrap 및 잘못된 ACK에
  대비해 DS NiFi 조각 처리를 보강했습니다.
- SGB opcode 목록 검사와 일반·UBSan·AddressSanitizer·누수 검사를 자동화했습니다.
- 영어·일본어·한국어 가이드와 프로그램 버전 정보를 갱신했습니다.

### 중요한 제한 사항

- 256/256은 opcode 분기 범위이며 완전하거나 사이클 정확한 SNES CPU라는 뜻이
  아닙니다. 사이클 계산·페널티, 외부 IRQ/참조 trace 및 실제 SGB 호스트
  프로그램 검증이 남아 있습니다.
- SPC700은 21/256이며 DSP 엔벌로프·에코와 프로토타입 호스트 OBJ 최종 합성도
  미완성입니다.
- 상태 파일은 구조적으로 선검사하지만 완전한 transaction 방식은 아닙니다.
  특히 이전 상태 파일은 백업을 유지하십시오.
- 소프트웨어 무선 시험은 DS↔DS, DSi↔DSi 및 3DS DS 모드 실기 시험을 대체하지
  않습니다.
- 네이티브 3DSX 작업은 `backup/3dsx`에 보류되어 있으며 포함하지 않습니다.

### 압축 파일 구성

- `gameyob.nds`
- `gameyob_dsi.nds`
- 영어·일본어·한국어 사용자 가이드
- 수정 가능한 INI·JSON·XML·YAML 언어 예제
- 라이선스 고지와 파일별 SHA-256 체크섬
