# GameYob v0.5.7-ko release record

## English

This is a DS/DSi-focused maintenance release. It keeps the emulator,
multilingual interface, Korean filename and cheat support, RTC, patched-ROM
hardening, BIOS selection, local link, and DS raw-NiFi work completed through
`v0.5.5-ko` while reorganizing distribution around the actively supported
NDS targets.

### Release changes

- Added the new `logo.png` project artwork to the repository and README.
- Derived a new 16-color 32×32 DS/DSi banner icon from the project logo.
- Updated build and debug version information to `v0.5.7-ko`.
- Limited the default package to `gameyob.nds` and `gameyob_dsi.nds`.
- Preserved the exact native `v0.5.5-ko` 3DSX executable and its SHA-256 under
  `backup/3dsx` instead of silently replacing or deleting it.
- Grouped native 3DS development into one deferred main TODO and recorded its
  detailed performance, scaling, rendering, audio, LAN, and bridge work in
  `backup/3dsx/TODO.md`.
- Changed native 3DS CI to a manual workflow and made 3DSX inclusion in the
  deterministic packager explicitly optional.
- Updated the English, Japanese, and Korean guides for the DS/DSi release.

### Package contents

- `gameyob.nds`
- `gameyob_dsi.nds`
- English, Japanese, and Korean user guides
- Editable INI, JSON, XML, and YAML language examples
- License notices and per-file SHA-256 checksums

The package does not contain a game ROM, BIOS, DSP firmware, or native 3DSX
executable. Nintendo 3DS users may run `gameyob.nds` in DS mode. The DSi file
requests DSi mode, but the launcher decides whether that mode and its extra
hardware resources are actually granted.

### Validation

- The repository tests and static checks must pass at the tagged revision.
- Both NDS outputs must be built in the pinned BlocksDS 1.22.2 container.
- The final ZIP is tested for integrity, expected members, and deterministic
  rebuild output before publication.
- User-confirmed physical DS/DSi behavior from the preceding stabilization
  work remains recorded in the repository history. The remaining cross-device
  NiFi and broader hardware matrix are tracked in the README TODO.

No ROM or BIOS is distributed.

## 한국어

이 버전은 DS/DSi 중심 유지보수 릴리스입니다. `v0.5.5-ko`까지 완성한 에뮬레이터,
다국어 메뉴, 한글 파일명·치트, RTC, 패치 ROM 안정화, BIOS 선택, 로컬 링크 및
DS raw-NiFi 작업을 유지하면서 실제 배포 대상을 NDS판 중심으로 정리했습니다.

### 릴리스 변경 사항

- 새 프로젝트 그림을 `logo.png`로 저장소와 README에 적용했습니다.
- 같은 로고를 바탕으로 16색 32×32 DS/DSi 배너 아이콘을 적용했습니다.
- 빌드 및 디버그 버전 정보를 `v0.5.7-ko`로 갱신했습니다.
- 기본 배포 파일을 `gameyob.nds`와 `gameyob_dsi.nds`로 정리했습니다.
- 기존 `v0.5.5-ko` 네이티브 3DSX 실행 파일과 SHA-256을 삭제하거나 바꾸지
  않고 `backup/3dsx`에 그대로 보존했습니다.
- 네이티브 3DS 작업을 메인 TODO의 단일 보류 항목으로 묶고, 성능·확대·화면·
  사운드·LAN·프로토콜 브리지 상세 작업을 `backup/3dsx/TODO.md`에 기록했습니다.
- 네이티브 3DS CI를 수동 실행 방식으로 바꾸고, 재현 가능한 패키징 도구에서
  3DSX 포함을 명시적인 선택 사항으로 변경했습니다.
- 영어·일본어·한국어 사용 가이드를 DS/DSi 배포에 맞게 갱신했습니다.

### 압축 파일 구성

- `gameyob.nds`
- `gameyob_dsi.nds`
- 영어·일본어·한국어 사용자 가이드
- 수정 가능한 INI·JSON·XML·YAML 언어 예제
- 라이선스 고지와 파일별 SHA-256 체크섬

게임 ROM, BIOS, DSP 펌웨어 및 네이티브 3DSX 실행 파일은 포함하지 않습니다.
Nintendo 3DS에서는 `gameyob.nds`를 DS 모드로 사용할 수 있습니다.
`gameyob_dsi.nds`는 DSi 모드를 요청하지만 실제 DSi 모드와 추가 자원 제공 여부는
사용하는 런처가 결정합니다.

### 검증

- 태그 리비전에서 저장소 테스트와 정적 검사를 통과해야 합니다.
- 고정된 BlocksDS 1.22.2 컨테이너에서 두 NDS 출력 파일을 빌드해야 합니다.
- 배포 전 최종 ZIP 무결성, 예상 파일 목록 및 재빌드 결정성을 확인해야 합니다.
- 앞선 안정화 과정에서 사용자가 확인한 DS/DSi 실기 결과는 저장소 기록에
  유지합니다. 남은 기기 조합별 NiFi와 확대된 실기 시험표는 README TODO에서
  추적합니다.

ROM과 BIOS는 배포하지 않습니다.
