# GameYob v0.5.9-ko release record

## English

This DS/DSi-focused release adds touch-driven menus and file selection, and
strengthens documented rare-cartridge and display/SGB protocol behavior. It is
built from the pinned BlocksDS 1.22.2 environment. The archive contains
redistributable homebrew only: no ROM, BIOS, DSP firmware, or native 3DSX
executable is included. Nintendo 3DS users can run the NDS build in Nintendo
3DS DS mode.

### Touch controls

- Added **Display → Touch Menu**, enabled by default and persisted through the
  normal settings path.
- Menus and the ROM/File Chooser temporarily appear on the physical Bottom
  Screen while touch navigation is active. The saved **Game Screen** value is
  not modified and is restored when the UI closes.
- A first tap selects a row. A second tap activates a selected action; the
  left/right halves of a selected value row choose the previous/next value.
  Title-row areas change category or close the menu. Chooser arrows scroll and
  its exit row performs Y.
- Touch-down edge and release arming prevent a contact that opened the menu
  from immediately activating an item. Hidden platform rows are mapped by
  visible row, not source index.
- Existing physical controls and the configurable gameplay Touch binding are
  preserved. Touch Menu can be disabled independently.

### Compatibility and cartridge work

- Added per-scanline WX hide/resume, WY, and enable-gating regression cases
  without changing the established DS hardware renderer path.
- Added portable SGB packet header validation for packet counts and all 32
  command IDs, plus the existing 11-byte DATA_SND bound.
- Replaced the MBC7 EEPROM placeholder with a bounded serial implementation of
  EWEN/EWDS, READ, WRITE, ERASE, WRAL, and ERAL; added dual access enables,
  documented X/Y latch behavior, battery persistence, and save-state data.
- Corrected HuC1 to use RAM/IR selection and independent six-bit ROM/two-bit
  RAM banking instead of MBC1 mode behavior. With no physical IR backend it
  reports no incoming light.
- Save-state version 8 explicitly records MBC7 transaction/latch/access state
  and HuC1 IR state while older state versions remain loadable.
- Cartridge IDs `0x15`-`0x17` remain intentionally unsupported because the
  public cartridge type specification defines no hardware for them. They are
  not guessed or aliased.

### Tests performed

Portable `-Wall -Wextra -Werror` tests cover touch hit testing and arming,
file-chooser touch behavior, MBC7 EEPROM commands/state, HuC1 mapper rules,
expanded WX behavior, SGB packet validation, and the prior NiFi, renderer,
noise, RTC, ROM layout, MMM01, SGB host/border, localization, file I/O,
Unicode, and path suites. The pinned BlocksDS CI builds both NDS targets.

Physical validation of the v0.5.9-ko touch and rare-cartridge changes was not
performed in the Codex environment and remains pending.

### Known limitations

- MBC7 programming busy time and physical sensor noise/timing are not modeled.
- HuC3's detailed MCU mailbox, IR, and tone generator remain partial.
- The SGB host is not complete: 51/256 65C816 and 21/256 SPC700 opcode cases
  are implemented; complete timing, DSP envelopes/echo, and final prototype
  OBJ composition remain TODO. Unsupported opcodes fault explicitly.
- Native 3DSX work remains paused under `backup/3dsx`.

### Package contents

- `gameyob.nds`
- `gameyob_dsi.nds`
- English, Japanese, and Korean user guides
- Editable INI, JSON, XML, and YAML language examples
- License notices and per-file SHA-256 checksums

## 한국어

이 DS/DSi 중심 릴리스는 터치 메뉴·파일 선택 기능과 희귀 카트리지 및
화면/SGB 프로토콜의 검증 범위를 추가합니다. 고정된 BlocksDS 1.22.2 환경으로
빌드하며 재배포 가능한 홈브루만 포함합니다. 게임 ROM, BIOS, DSP 펌웨어 및
네이티브 3DSX 실행 파일은 포함하지 않습니다. Nintendo 3DS 사용자는 NDS판을
Nintendo 3DS의 DS 모드에서 실행할 수 있습니다.

### 터치 조작

- 기본값이 켜짐인 **화면 → 터치 메뉴**를 추가하고 기존 설정 경로로 저장합니다.
- 터치 조작 중 메뉴와 ROM/파일 선택기는 실제 아래 화면에 임시 표시됩니다.
  저장된 **게임 화면** 값은 변경하지 않으며 UI를 닫으면 원래 배치로 돌아갑니다.
- 처음 터치하면 선택만 하고 선택된 실행 항목을 다시 터치하면 실행합니다.
  선택된 값 항목의 왼쪽/오른쪽은 이전/다음 값이며, 제목 줄은 분류 이동과
  닫기를 담당합니다. 파일 선택기의 화살표는 스크롤하고 종료 행은 Y와 같습니다.
- 새 터치 경계와 release 대기로 메뉴를 연 같은 접촉이 항목까지 실행하지 않게
  했으며, 플랫폼에서 숨겨진 행은 실제 보이는 행 기준으로 계산합니다.
- 기존 물리 버튼과 게임 중 설정 가능한 Touch 매핑은 유지하며 터치 메뉴만
  독립적으로 끌 수 있습니다.

### 호환성 및 카트리지

- 기존 DS 하드웨어 렌더러를 유지하면서 주사선별 WX 숨김/재개, WY 및 창 활성
  조건의 자동 시험을 확대했습니다.
- 32개 SGB 명령 ID와 패킷 수의 헤더 검사 및 DATA_SND 11바이트 경계 시험을
  추가했습니다.
- 비어 있던 MBC7 EEPROM 경로를 EWEN/EWDS·READ·WRITE·ERASE·WRAL·ERAL 직렬
  상태 기계로 교체하고 이중 활성화, X/Y 래치, 배터리 저장 및 상태 저장을
  연결했습니다.
- HuC1을 MBC1 모드 방식 대신 RAM/IR 선택, 6비트 ROM 및 독립 2비트 RAM
  뱅킹으로 수정했습니다. 물리 IR 백엔드가 없으므로 수신광 없음으로 읽습니다.
- 상태 파일 버전 8이 MBC7 거래·래치·활성 상태와 HuC1 IR 상태를 명시적으로
  저장하며 이전 상태 파일도 계속 불러옵니다.
- `0x15`-`0x17`은 공개 카트리지 형식표에 하드웨어 정의가 없어 추측하거나 다른
  매퍼로 대체하지 않고 계속 미지원으로 둡니다.

### 수행한 시험

터치 hit-test·release 대기·파일 선택, MBC7 EEPROM 명령·상태, HuC1 규칙,
확대된 WX, SGB 패킷과 기존 NiFi·렌더러·노이즈·RTC·ROM 배치·MMM01·SGB
호스트/보더·다국어·파일 I/O·유니코드·경로 회귀시험을
`-Wall -Wextra -Werror`로 수행합니다. 고정 BlocksDS CI에서 두 NDS 대상을
빌드합니다.

Codex 환경에서는 v0.5.9-ko의 터치 및 희귀 실물 카트리지 변경을 실기로
검증하지 못했으며 이 항목은 남아 있습니다.

### 알려진 제한

- MBC7 프로그래밍 busy 시간과 실제 센서 잡음·타이밍은 모델링하지 않았습니다.
- HuC3의 상세 MCU mailbox·IR·톤 발생기는 부분 구현입니다.
- SGB 호스트는 완전하지 않습니다. 65C816 51/256, SPC700 21/256 opcode case만
  구현되어 있으며 전체 타이밍, DSP 엔벌로프·에코, 프로토타입 OBJ 최종 합성이
  남아 있습니다. 미지원 명령은 조용히 무시하지 않고 명시적으로 중단합니다.
- 네이티브 3DSX 작업은 `backup/3dsx`에 보류되어 있습니다.

### 압축 파일 구성

- `gameyob.nds`
- `gameyob_dsi.nds`
- 영어·일본어·한국어 사용자 가이드
- 수정 가능한 INI·JSON·XML·YAML 언어 예제
- 라이선스 고지와 파일별 SHA-256 체크섬
