GameYob v0.5.3-ko

Included homebrew builds:

gameyob.nds
  Nintendo DS/DS Lite, Nintendo 3DS DS mode, and most flashcards.

gameyob_dsi.nds
  Launchers that explicitly support DSi mode.

gameyob.3dsx
  Native Nintendo 3DS homebrew.

The NDS and DSi files use the same emulator core. The DSi file has a
DSi-aware header for compatible launchers and does not by itself guarantee
a performance improvement.

Detailed changes, verification records, and remaining TODO items:
https://github.com/GimoXagros/GameYob/blob/master/README.md

GameYob and this modification are distributed under the MIT License.
The embedded Korean bitmap font is derived from Galmuri and distributed
under the SIL Open Font License 1.1. See the included license files.
No game ROM or BIOS file is included.

한국어 안내

포함된 홈브루 빌드:

gameyob.nds
  Nintendo DS/DS Lite, Nintendo 3DS의 DS 모드 및 대부분의 플래시카드용

gameyob_dsi.nds
  DSi 모드를 명시적으로 지원하는 런처용

gameyob.3dsx
  네이티브 Nintendo 3DS 홈브루용

NDS판과 DSi판은 같은 에뮬레이터 코어를 사용합니다. DSi판은 호환 런처를
위한 DSi용 헤더를 사용하며, 파일 자체가 성능 향상을 보장하지는 않습니다.

자세한 변경 사항, 검증 기록 및 남은 TODO 항목은 위 저장소 README에
영문과 한글로 기록되어 있습니다. 게임 ROM과 BIOS는 포함하지 않습니다.
